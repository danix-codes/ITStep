from flask import Flask, render_template
from random import randint

app = Flask(__name__)

@app.route("/", methods=["GET"])
def home():
    return render_template("home.html")

@app.route("/about", methods=["GET"])
def about():
    name = "Adam"
    age = randint(5, 80)
    return render_template("about.html", user_name=name, user_age=age)


if __name__ == "__main__":
    app.run(debug=True) 